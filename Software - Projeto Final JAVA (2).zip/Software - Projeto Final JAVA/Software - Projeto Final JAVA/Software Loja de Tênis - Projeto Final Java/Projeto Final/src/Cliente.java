public class Cliente extends Pessoa {
    private String endereco;
    private String email;
    private String telefone;

    public Cliente(String nome, int idade, String endereco, String email, String telefone) {
        super(nome, idade);
        this.endereco = endereco;
        this.email = email;
        this.telefone = telefone;
    }

    public void exibir() {
        System.out.println("Nome: " + nome);
        System.out.println("Idade: " + idade);
        System.out.println("Endereço: " + endereco);
        System.out.println("Email: " + email);
        System.out.println("Telefone: " + telefone);
    }
}
