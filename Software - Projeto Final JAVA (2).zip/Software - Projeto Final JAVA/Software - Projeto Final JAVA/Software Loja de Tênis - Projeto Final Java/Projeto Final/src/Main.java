import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

    /*Foram usados métodos statc pois eles precisam ser chamados
    sem depender da criação de um objeto (instância)

    Autores: Lucas Henrique e Martins
             Abner Vinícius Amais Viola

    Tema: Software Loja de Tênis - Projeto Final JAVA

    A exceção InputMismatchException foi tratada para evitar
    erro na entrada de dados pelo Scanner*/

public class Main {

    public static void main(String[] args) {
        Main main = new Main();
        main.executar();
    }

    public void executar() {
        ArrayList<Cliente> clientes = new ArrayList<>();
        ArrayList<Funcionario> funcionarios = new ArrayList<>();
        ArrayList<Produto> produtos = new ArrayList<>();

        Scanner scanner = new Scanner(System.in);
        int opcao;

        do {
            System.out.println("=== MENU ===");
            System.out.println("1. Cadastrar cliente");
            System.out.println("2. Cadastrar funcionário");
            System.out.println("3. Cadastrar produto");
            System.out.println("4. Buscar cliente por nome");
            System.out.println("5. Buscar funcionário por nome");
            System.out.println("6. Buscar produto por descrição");
            System.out.println("7. Buscar produto por preço");
            System.out.println("8. Mostrar informações dos clientes");
            System.out.println("9. Mostrar informações dos funcionários");
            System.out.println("10. Mostrar informações dos produtos");
            System.out.println("11. Buscar clientes com + 60 anos");
            System.out.println("12. Buscar clientes com menos de 18 anos");
            System.out.println("13. Exibir média das idades");
            System.out.println("14. Exibir cliente mais velho");
            System.out.println("15. Exibir cliente mais novo");
            System.out.println("16. Exibir o produto mais caro");
            System.out.println("17. Exibir o produto mais barato");
            System.out.println("18. Quantidade de produtos com preço acima da média");
            System.out.println("19. Sair");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = scanner.nextInt();
                switch (opcao) {
                    case 1:
                        cadastrarCliente(scanner, clientes);
                        break;
                    case 2:
                        cadastrarFuncionario(scanner, funcionarios);
                        break;
                    case 3:
                        cadastrarProduto(scanner, produtos);
                        break;
                    case 4:
                        buscarClientePorNome(scanner, clientes);
                        break;
                    case 5:
                        buscarFuncionarioPorNome(scanner, funcionarios);
                        break;
                    case 6:
                        buscarProdutoPorDescricao(scanner, produtos);
                        break;
                    case 7:
                        buscarProdutoPorDescricao(scanner,produtos);
                        break;
                    case 8:
                        mostrarInformacoesClientes(clientes);
                        break;
                    case 9:
                        mostrarInformacoesFuncionarios(funcionarios);
                        break;
                    case 10:
                        mostrarInformacoesProdutos(produtos);
                        break;
                    case 11:
                        QntdClientesComMaisDe60Anos(clientes);
                        break;
                    case 12:
                        QntdClientesComMenosDe18Anos(clientes);
                        break;
                    case 13:
                        calcularMediaIdadesClientes(clientes);
                        break;
                    case 14:
                        exibirClienteMaisVelho(clientes);
                        break;
                    case 15:
                        exibirClienteMaisNovo(clientes);
                        break;
                    case 16:
                        exibirProdutoMaisCaro(produtos);
                        break;
                    case 17:
                        exibirProdutoMaisBarato(produtos);
                        break;
                    case 18:
                        contarProdutosAcimaMedia(produtos);
                    case 19:
                        System.out.println("Saindo...");
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Erro: Opção inválida. Certifique-se de inserir um número.");
                scanner.nextLine();
                opcao = 0;
            }
        } while (opcao != 19);

        scanner.close();
    }

    // Cadastra um cliente
    public void cadastrarCliente(Scanner scanner, ArrayList<Cliente> clientes) {
        System.out.println("== Cadastro de Cliente ==");
        scanner.nextLine();

        String nome = "";
        int idade = -1;
        String telefone = "";
        String email = "";
        String endereco = "";

        while (nome.length() < 3) {
            System.out.print("Nome (mínimo 3 caracteres): ");
            nome = scanner.nextLine();
            if (nome.length() < 3) {
                System.out.println("Erro: O nome deve ter pelo menos 3 caracteres. Por favor, insira um nome válido.");
            }
        }

        while (idade < 0) {
            try {
                System.out.print("Idade: ");
                idade = scanner.nextInt();
                if (idade < 0) {
                    System.out.println("Erro: A idade não pode ser negativa. Por favor, insira um valor válido.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Erro: Formato inválido. Insira um valor numérico para a idade.");
                scanner.nextLine();
            }
        }
        scanner.nextLine();

        while (telefone.length() < 11) {
            System.out.print("Telefone (mínimo 11 caracteres): ");
            telefone = scanner.nextLine();
            if (telefone.length() < 11) {
                System.out.println("Erro: O telefone deve ter pelo menos 11 dígitos. Por favor, insira um número de telefone válido.");
            }
        }

        while (endereco.length() < 7) {
            System.out.print("Endereço (mínimo 7 caracteres): ");
            endereco = scanner.nextLine();
            if (endereco.length() < 7) {
                System.out.println("Erro: O endereço deve ter pelo menos 7 caracteres. Por favor, insira um endereço válido.");
            }
        }

        while (!email.contains("@") || email.length() < 7) {
            System.out.print("Email (mínimo 7 caracteres e deve conter '@'): ");
            email = scanner.nextLine();
            if (!email.contains("@") || email.length() < 7) {
                System.out.println("Erro: O email deve conter o caractere '@' e ter pelo menos 7 caracteres. Por favor, insira um email válido.");
            }
        }

        Cliente cliente = new Cliente(nome, idade, endereco, email, telefone);
        clientes.add(cliente);
        System.out.println("Cliente cadastrado com sucesso.");
    }

    // Cadastra um funcionário
    public void cadastrarFuncionario(Scanner scanner, ArrayList<Funcionario> funcionarios) {
        System.out.println("== Cadastro de Funcionário ==");
        scanner.nextLine();

        String nome = "";
        int idade = -1;
        String cargo = "";
        double salario = -1.0;

        while (nome.isEmpty()) {
            System.out.print("Nome: ");
            nome = scanner.nextLine();
            if (nome.isEmpty()) {
                System.out.println("Erro: O nome não pode estar vazio. Por favor, insira um nome válido.");
            }
        }

        while (idade < 0) {
            try {
                System.out.print("Idade: ");
                idade = scanner.nextInt();
                if (idade < 0) {
                    System.out.println("Erro: A idade não pode ser negativa. Por favor, insira uma idade válida.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Erro: Formato inválido. Insira um valor numérico para a idade.");
                scanner.nextLine();
            }
        }
        scanner.nextLine();

        while (cargo.isEmpty()) {
            System.out.print("Cargo: ");
            cargo = scanner.nextLine();
            if (cargo.isEmpty()) {
                System.out.println("Erro: O cargo não pode estar vazio. Por favor, insira um cargo válido.");
            }
        }

        while (salario < 0) {
            try {
                System.out.print("Salário: ");
                salario = scanner.nextDouble();
                if (salario < 0) {
                    System.out.println("Erro: O salário não pode ser negativo. Por favor, insira um valor válido.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Erro: Formato inválido. Insira um valor numérico para o salário.");
                scanner.nextLine();
            }
        }

        Funcionario funcionario = new Funcionario(nome, idade, cargo, salario);
        funcionarios.add(funcionario);
        System.out.println("Funcionário cadastrado com sucesso.");
    }

    // Cadastra um produto
    public void cadastrarProduto(Scanner scanner, ArrayList<Produto> produtos) {
        System.out.println("== Cadastro de Produto ==");
        scanner.nextLine();

        String codigo = "";
        String descricao = "";
        double preco = -1.0;

        while (codigo.length() < 6) {
            System.out.print("Código (mínimo 6 caracteres, apenas números): ");
            codigo = scanner.nextLine();
            if (!codigo.matches("\\d{6}")) //Confirmar com a professora ?
                {
                System.out.println("Erro: O código deve conter 6 dígitos numéricos.");
                codigo = "";
            }
        }

        while (preco < 1) {
            try {
                System.out.print("Preço (maior ou igual a 1): ");
                preco = scanner.nextDouble();
                if (preco < 1) {
                    System.out.println("Erro: O preço não pode ser menor que 1.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Erro: Formato inválido. Insira um valor numérico.");
                scanner.nextLine();
            }
        }

        scanner.nextLine();

        while (descricao.length() < 10) {
            System.out.print("Descrição (mínimo 10 caracteres): ");
            descricao = scanner.nextLine();
            if (descricao.length() < 10) {
                System.out.println("Erro: A descrição deve ter pelo menos 10 caracteres.");
            }
        }

        Produto produto = new Produto(descricao, preco, codigo);
        produtos.add(produto);
        System.out.println("Produto cadastrado com sucesso.");
    }

    // Busca os clientes por nome
    public void buscarClientePorNome(Scanner scanner, ArrayList<Cliente> clientes) {
        System.out.print("Digite parte do nome do cliente: ");
        String parteNome = scanner.next();
        boolean encontrado = false;
        for (Cliente cliente : clientes) {
            if (cliente.getNome().toLowerCase().startsWith(parteNome.toLowerCase())) {
                cliente.exibir();
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Não há clientes cadastrados com esse nome!");
        }
    }

    // Busca os funcionários por nome
    public void buscarFuncionarioPorNome(Scanner scanner, ArrayList<Funcionario> funcionarios) {
        System.out.print("Digite parte do nome do funcionário: ");
        String parteNome = scanner.next();
        boolean encontrado = false;
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getNome().toLowerCase().startsWith(parteNome.toLowerCase())) {
                funcionario.exibir();
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Não há funcionários cadastrados com esse nome!");
        }
    }

    // Busca os produtos por descrição
    public void buscarProdutoPorDescricao(Scanner scanner, ArrayList<Produto> produtos) {
        System.out.print("Digite parte da descrição do produto: ");
        String parteDescricao = scanner.next();
        boolean encontrado = false;
        for (Produto produto : produtos) {
            if (produto.getDescricao().toLowerCase().contains(parteDescricao.toLowerCase())) {
                System.out.println("Descrição: " + produto.getDescricao() + ", Preço: " + produto.getPreco());
                encontrado = true;
            }
        }
        if (!encontrado) {
            System.out.println("Não há produtos cadastrados com essa descrição!");
        }
    }

    // Busca produtos por preço
    public void buscarProdutosPorFaixaDePreco(Scanner scanner, ArrayList<Produto> produtos) {
        System.out.println("== Buscar Produtos por Faixa de Preço ==");

        double precoMinimo = 0.0;
        double precoMaximo = 0.0;

        while (true) {
            try {
                System.out.print("Insira o valor mínimo: ");
                String input = scanner.next();
                precoMinimo = Double.parseDouble(input);
                break; // Sai do loop se a entrada for válida
            } catch (NumberFormatException e) {
                System.out.println("Erro: Insira um valor numérico válido para o preço mínimo.");
                scanner.nextLine();
            }
        }

        while (true) { // Loop infinito
            try {
                System.out.print("Insira o valor máximo: ");
                String input = scanner.next();
                precoMaximo = Double.parseDouble(input);
                break; // Sai do loop se a entrada for válida
            } catch (NumberFormatException e) {
                System.out.println("Erro: Insira um valor numérico válido para o preço máximo.");
                scanner.nextLine();
            }
        }

        boolean encontrouProdutos = false;
        System.out.println("== Produtos na Faixa de Preço de R$" + precoMinimo + " a R$" + precoMaximo + " ==");
        for (Produto produto : produtos) {
            if (produto.getPreco() >= precoMinimo && produto.getPreco() <= precoMaximo) {
                System.out.println("Descrição: " + produto.getDescricao() + ", Preço: " + produto.getPreco());
                encontrouProdutos = true;
            }
        }

        if (!encontrouProdutos) {
            System.out.println("Não há produtos nesta faixa de preço.");
        }
    }

    // Exibe as informações dos Clientes
    public void mostrarInformacoesClientes(ArrayList<Cliente> clientes) {
        System.out.println("== Informações dos Clientes ==");
        if (clientes.isEmpty()) {
            System.out.println("Não há clientes cadastrados!");
        }
        for (Cliente cliente : clientes) {
            cliente.exibir();
            System.out.println();
        }
    }

    // Exibe as informações dos funcionários
    public void mostrarInformacoesFuncionarios(ArrayList<Funcionario> funcionarios) {
        System.out.println("== Informações dos Funcionários ==");
        if (funcionarios.isEmpty()) {
            System.out.println("Não há funcionários cadastrados!");
        }
        for (Funcionario funcionario : funcionarios) {
            funcionario.exibir();
            System.out.println();
        }
    }

    // Exibe as informações dos produtos
    public void mostrarInformacoesProdutos(ArrayList<Produto> produtos) {
        System.out.println("== Informações dos Produtos ==");
        if (produtos.isEmpty()) {
            System.out.println("Não há produtos cadastrados!");
        }
        for (Produto produto : produtos) {
            System.out.println("Descrição: " + produto.getDescricao() + ", Preço: " + produto.getPreco());
        }
    }

    // Busca clientes com mais de 60 anos
    public void QntdClientesComMaisDe60Anos(ArrayList<Cliente> clientes) {
        int count = 0;
        for (Cliente cliente : clientes) {
            if (cliente.getIdade() > 60) {
                count++;
            }
        }
        System.out.println("Quantidade de clientes com mais de 60 anos: " + count);
    }

    // Busca clientes com menos de 18 anos
    public void QntdClientesComMenosDe18Anos(ArrayList<Cliente> clientes) {
        int count = 0;
        for (Cliente cliente : clientes) {
            if (cliente.getIdade() < 18) {
                count++;
            }
        }
        System.out.println("Quantidade de clientes com menos de 18 anos: " + count);
    }

    // Calcula a média das idades
    public void calcularMediaIdadesClientes(ArrayList<Cliente> clientes) {
        if (clientes.isEmpty()) {
            System.out.println("Não há clientes cadastrados.");
        }

        int somaIdades = 0;
        for (Cliente cliente : clientes) {
            somaIdades += cliente.getIdade();
        }

        double media = (double) somaIdades / clientes.size();
        System.out.println("Média de idades dos clientes: " + media);
    }

    // Exibe o cliente mais velho
    public void exibirClienteMaisVelho(ArrayList<Cliente> clientes) {
        if (clientes.isEmpty()) {
            System.out.println("Não há clientes cadastrados.");
            return;
        }

        Cliente clienteMaisVelho = clientes.get(0);
        for (Cliente cliente : clientes) {
            if (cliente.getIdade() > clienteMaisVelho.getIdade()) {
                clienteMaisVelho = cliente;
            }
        }

        System.out.println("=== Cliente Mais Velho ===");
        clienteMaisVelho.exibir();
    }

    // Exibe o cliente mais novo
    public void exibirClienteMaisNovo(ArrayList<Cliente> clientes) {
        if (clientes.isEmpty()) {
            System.out.println("Não há clientes cadastrados.");
            return;
        }

        Cliente clienteMaisNovo = clientes.get(0);
        for (Cliente cliente : clientes) {
            if (cliente.getIdade() < clienteMaisNovo.getIdade()) {
                clienteMaisNovo = cliente;
            }
        }

        System.out.println("=== Cliente Mais Novo ===");
        clienteMaisNovo.exibir();
    }

    // Exibe o produto mais caro
    public void exibirProdutoMaisCaro(ArrayList<Produto> produtos) {
        if (produtos.isEmpty()) {
            System.out.println("Não há produtos cadastrados.");
            return;
        }

        Produto maisCaro = produtos.get(0);

        for (Produto produto : produtos) {
            if (produto.getPreco() > maisCaro.getPreco()) {
                maisCaro = produto;
            }
        }

        System.out.println("== Produto mais caro ==");
        maisCaro.exibir();
    }

    // Exibe o produto mais barato
    public void exibirProdutoMaisBarato(ArrayList<Produto> produtos) {
        if (produtos.isEmpty()) {
            System.out.println("Não há produtos cadastrados.");
            return;
        }

        Produto maisBarato = produtos.get(0);

        for (Produto produto : produtos) {
            if (produto.getPreco() < maisBarato.getPreco()) {
                maisBarato = produto;
            }
        }

        if (maisBarato == null) {
            System.out.println("Não foi possível determinar o produto mais barato.");
        } else {
            System.out.println("== Produto mais barato ==");
            System.out.println("Descrição: " + maisBarato.getDescricao() + ", Preço: " + maisBarato.getPreco());
        }
    }

    // Exibir qntd de produtos acima da média
    public void contarProdutosAcimaMedia(ArrayList<Produto> produtos) {
        if (produtos.isEmpty()) {
            System.out.println("Não há produtos cadastrados.");
            return;
        }

        double somaPrecos = 0;
        for (Produto produto : produtos) {
            somaPrecos += produto.getPreco();
        }

        double media = somaPrecos / produtos.size();
        int count = 0;
        for (Produto produto : produtos) {
            if (produto.getPreco() > media) {
                count++;
            }
        }
        System.out.println("Quantidade de produtos com preço acima da média: " + count);
    }
}


