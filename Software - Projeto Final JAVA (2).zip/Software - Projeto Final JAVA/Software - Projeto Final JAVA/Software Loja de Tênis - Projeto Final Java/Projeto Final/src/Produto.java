public class Produto implements IPessoa {
    private String descricao;
    private double preco;
    private String codigo;

    public Produto(String descricao, double preco, String codigo) {
        this.descricao = descricao;
        this.preco = preco;
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao() {
        this.descricao = descricao;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco() {
        this.preco = preco;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    @Override
    public void exibir() {
        System.out.println("Descrição: " + descricao);
        System.out.println("Preço: " + preco);
        System.out.println("Código: " + codigo);
    }
}
